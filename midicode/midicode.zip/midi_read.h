
// General Use
int midi_readHdr(FILE *mf,MIDIHdr *mh);
int midi_readTrk(FILE *mf,MIDITrk *mt);

// Really nice to have
int midi_readDeltaTime(byte *,unsigned long *);

