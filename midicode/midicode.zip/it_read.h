int it_readhdr  (Ithdr  *, FILE *);
int it_readinst (Itinst *, FILE *);
int it_readsamp (Itsamp *, FILE *);
int it_readpatt (Itpatt *, FILE *);



