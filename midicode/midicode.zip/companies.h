typedef struct 
{
  char *name;
  unsigned int ID;
} MIDImfr;

void LookupManuID(unsigned int,char *);
