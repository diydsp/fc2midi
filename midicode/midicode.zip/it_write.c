#include <stdio.h>
#include "useful.h"
#include "it_types.h"
#include "it_write.h"

int it_writeHdr(FILE *fi,Ithdr *ith)
{

  return(1);
}
