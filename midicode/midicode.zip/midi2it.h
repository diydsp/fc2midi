int it2midi(FILE *itf,FILE *mf);
