void it_disphdr  (Ithdr  *);
void it_dispflags(unsigned char);
void it_dispspecial(unsigned char);
void it_dispinst (Itinst *);
void it_dispsamp (Itsamp *);
void it_disppatt (Itpatt *);


