int it_writeHdr(FILE *fi,Ithdr *ith);
