void midi_dispHdr(MIDIHdr *);
void midi_dispTrk(MIDITrk *trk);

void LookupNoteNum(byte,char *);

