int examidi(FILE *mf);

